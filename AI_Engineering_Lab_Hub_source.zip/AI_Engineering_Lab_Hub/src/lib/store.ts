import { create } from "zustand";

// Global client state shared across pages. Progress, teacher notes and student
// lab-log drafts are kept in memory and mirrored to this browser's local
// storage when it is available (it is not in some embedded previews, in which
// case everything simply lives for the current visit).

const STORAGE_KEY = "ai-engineering-lab-hub:v1";

export interface LabLogDraft {
  studentName: string;
  answers: Record<number, string>; // step number → answer
  exitAnswer: string;
  updatedAt: string; // ISO timestamp
}

interface PersistedSlice {
  taught: Record<string, boolean>;
  teacherNotes: Record<string, string>;
  labLogs: Record<string, LabLogDraft>;
}

interface AppState extends PersistedSlice {
  selectedLabId: string | null;
  storageAvailable: boolean;
  selectLab: (id: string | null) => void;
  toggleTaught: (labId: string) => void;
  setTeacherNote: (labId: string, note: string) => void;
  updateLabLog: (labId: string, patch: Partial<LabLogDraft>) => void;
  clearLabLog: (labId: string) => void;
}

function readStorage(): { data: Partial<PersistedSlice>; available: boolean } {
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return { data: {}, available: true };
    const parsed: unknown = JSON.parse(raw);
    if (parsed && typeof parsed === "object") {
      return { data: parsed as Partial<PersistedSlice>, available: true };
    }
    return { data: {}, available: true };
  } catch {
    return { data: {}, available: false };
  }
}

function writeStorage(slice: PersistedSlice) {
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(slice));
  } catch {
    // Storage is unavailable here — state stays in memory for this visit.
  }
}

const initial = readStorage();

export const useAppStore = create<AppState>((set, get) => {
  const persist = () => {
    const { taught, teacherNotes, labLogs } = get();
    writeStorage({ taught, teacherNotes, labLogs });
  };
  return {
    taught: initial.data.taught ?? {},
    teacherNotes: initial.data.teacherNotes ?? {},
    labLogs: initial.data.labLogs ?? {},
    selectedLabId: null,
    storageAvailable: initial.available,
    selectLab: (id) => set({ selectedLabId: id }),
    toggleTaught: (labId) => {
      set((s) => ({ taught: { ...s.taught, [labId]: !s.taught[labId] } }));
      persist();
    },
    setTeacherNote: (labId, note) => {
      set((s) => ({ teacherNotes: { ...s.teacherNotes, [labId]: note } }));
      persist();
    },
    updateLabLog: (labId, patch) => {
      set((s) => {
        const current: LabLogDraft = s.labLogs[labId] ?? {
          studentName: "",
          answers: {},
          exitAnswer: "",
          updatedAt: new Date().toISOString(),
        };
        return {
          labLogs: {
            ...s.labLogs,
            [labId]: {
              ...current,
              ...patch,
              answers: { ...current.answers, ...(patch.answers ?? {}) },
              updatedAt: new Date().toISOString(),
            },
          },
        };
      });
      persist();
    },
    clearLabLog: (labId) => {
      set((s) => {
        const next = { ...s.labLogs };
        delete next[labId];
        return { labLogs: next };
      });
      persist();
    },
  };
});
