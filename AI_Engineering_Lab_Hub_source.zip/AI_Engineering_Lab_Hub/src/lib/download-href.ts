// Build the URL of a bundled class document (served from the app's own
// `downloads/` folder). Uses the build base so the link works both in the
// live preview and in the published app.
export function downloadHref(file: string): string {
  const base = import.meta.env.BASE_URL;
  const normalized = base.endsWith("/") ? base : `${base}/`;
  return `${normalized}downloads/${encodeURIComponent(file)}`;
}
