// Course content for the AI Engineering Lab (Fall 2026).
// Every mission, exit check, link, step and prompt below is taken from the
// class documents: Student Course Hub, AI Engineer Lab Notebook, Sub Day
// Student Packets, and the AI Innovation Canvas + Demo Day sheet.

export const classInfo = {
  title: "AI Engineering Lab",
  club: "Club C",
  ages: "Ages 13-16",
  meets: "Tuesdays 12:30-1:15 PM",
  term: "Fall 2026",
  sessionMinutes: 45,
  tagline: "Train it. Test it. Break it. Improve it.",
  mindset:
    "Define the problem. Make a prediction. Build or model. Test it. Use evidence. Improve the next version.",
  engineeringThinking:
    "Engineering is different from simply having an idea. Engineers define a need and constraints, test under real conditions, use evidence, study failure, and iterate.",
  aiSafety:
    "Do not enter passwords, addresses, phone numbers, private family or medical information, or another person's private data into an AI tool. We test AI output instead of assuming it is correct.",
  cameraRule:
    "Use hands, objects, or poses only. Do not create face/identity-recognition datasets of classmates.",
  subDayJob: "Train it → Test it → Find the weakness → Improve it → Show evidence.",
};

export const engineeringCycle = [
  "Define",
  "Predict",
  "Build / Model",
  "Test",
  "Evidence",
  "Improve",
] as const;

export interface LinkResource {
  id: string;
  title: string;
  source: string;
  url: string;
  kind: "video" | "tool" | "library";
  note?: string;
}

export const videos: LinkResource[] = [
  {
    id: "what-is-ml",
    title: "What is Machine Learning?",
    source: "Code.org",
    url: "https://www.youtube.com/watch?v=KHbwOetbmbs",
    kind: "video",
  },
  {
    id: "computer-vision",
    title: "How Computer Vision Works",
    source: "Code.org",
    url: "https://www.youtube.com/watch?v=2hXG8v8p0KM",
    kind: "video",
  },
  {
    id: "chatbots-llms",
    title: "How Chatbots and Large Language Models Work",
    source: "Code.org",
    url: "https://www.youtube.com/watch?v=X-AWdfSFCHQ",
    kind: "video",
  },
  {
    id: "training-data-bias",
    title: "AI: Training Data & Bias",
    source: "Code.org",
    url: "https://www.youtube.com/watch?v=x2mRoFNm22g",
    kind: "video",
  },
  {
    id: "nasa-edp",
    title: "Engineering Design Process",
    source: "NASA",
    url: "https://www.youtube.com/watch?v=IbbxjA5e2hw",
    kind: "video",
  },
];

export const videoLibrary: LinkResource = {
  id: "codeorg-library",
  title: "Code.org AI Video Library",
  source: "Code.org",
  url: "https://code.org/en-US/resources/videos",
  kind: "library",
};

export const tools: LinkResource[] = [
  {
    id: "quick-draw",
    title: "Google Quick, Draw!",
    source: "Google",
    url: "https://quickdraw.withgoogle.com/",
    kind: "tool",
    note: "A neural network guesses what you are doodling. Used to investigate how a machine-learning system recognizes patterns and what its mistakes can teach us.",
  },
  {
    id: "teachable-machine",
    title: "Google Teachable Machine",
    source: "Google",
    url: "https://teachablemachine.withgoogle.com/",
    kind: "tool",
    note: "No-code training for image and pose models. Image Project → Standard Image Model is used for the classifier labs; the Pose Project is used on costume day.",
  },
];

export interface Lab {
  id: string;
  number: number;
  date: string; // ISO date
  dateLabel: string;
  title: string;
  shortTitle: string;
  mission: string;
  watch?: string; // video id
  open?: string; // tool id
  openLabel?: string; // display label for the tool as written in the hub
  exitCheck: string;
  subDay: boolean;
  packet?: string; // download id
  kind: "lab" | "design" | "demo";
}

export const labs: Lab[] = [
  {
    id: "lab-1",
    number: 1,
    date: "2026-09-15",
    dateLabel: "Tue Sep 15",
    title: "Can You Outsmart AI?",
    shortTitle: "Outsmart AI",
    mission:
      "Investigate how a machine-learning system recognizes patterns and what its mistakes can teach us.",
    watch: "what-is-ml",
    open: "quick-draw",
    openLabel: "Google Quick, Draw!",
    exitCheck: "What condition made the AI easiest or hardest to fool?",
    subDay: false,
    kind: "lab",
  },
  {
    id: "lab-2",
    number: 2,
    date: "2026-09-22",
    dateLabel: "Tue Sep 22",
    title: "Train Your First AI",
    shortTitle: "Train Your First AI",
    mission:
      "Train a real image classifier, test it with new examples, and improve the weakest class.",
    watch: "computer-vision",
    open: "teachable-machine",
    openLabel: "Google Teachable Machine",
    exitCheck:
      "What did you change, and what evidence showed whether it improved?",
    subDay: false,
    kind: "lab",
  },
  {
    id: "lab-3",
    number: 3,
    date: "2026-09-29",
    dateLabel: "Tue Sep 29",
    title: "Rock-Paper-Scissors AI Challenge",
    shortTitle: "Rock-Paper-Scissors",
    mission:
      "Train Rock, Paper, and Scissors; test 10 trials; improve the weakest class; test again.",
    open: "teachable-machine",
    openLabel: "Google Teachable Machine",
    exitCheck: "Before: ___/10. After: ___/10. What changed?",
    subDay: true,
    packet: "sub-packets",
    kind: "lab",
  },
  {
    id: "lab-4",
    number: 4,
    date: "2026-10-13",
    dateLabel: "Tue Oct 13",
    title: "Prompt Engineering Battle",
    shortTitle: "Prompt Battle",
    mission:
      "Turn vague instructions into clear, testable requirements and evaluate whether AI followed them.",
    watch: "chatbots-llms",
    exitCheck:
      "What requirement did the AI miss, and how would you rewrite the prompt?",
    subDay: false,
    kind: "lab",
  },
  {
    id: "lab-5",
    number: 5,
    date: "2026-10-20",
    dateLabel: "Tue Oct 20",
    title: "Design an AI Invention",
    shortTitle: "AI Invention",
    mission:
      "Start with a user need, then design input → AI decision → output and define how you would test it.",
    watch: "nasa-edp",
    exitCheck:
      "Who is the user, and what measurable result would prove the idea helps?",
    subDay: false,
    kind: "design",
  },
  {
    id: "lab-6",
    number: 6,
    date: "2026-10-27",
    dateLabel: "Tue Oct 27",
    title: "Monster Moves AI Lab",
    shortTitle: "Monster Moves",
    mission:
      "Use costume day to stress-test a no-code pose model under different clothing and environment conditions.",
    watch: "computer-vision",
    open: "teachable-machine",
    openLabel: "Google Teachable Machine - Pose Project",
    exitCheck:
      "Which costume or environment condition affected predictions most?",
    subDay: false,
    kind: "lab",
  },
  {
    id: "lab-7",
    number: 7,
    date: "2026-11-10",
    dateLabel: "Tue Nov 10",
    title: "Break the AI: Background Bias Challenge",
    shortTitle: "Background Bias",
    mission:
      "Build a deliberately flawed thumbs-up/thumbs-down model, expose the shortcut it learned, then repair the data.",
    watch: "training-data-bias",
    open: "teachable-machine",
    openLabel: "Google Teachable Machine",
    exitCheck:
      "What unintended pattern did the model learn, and how did you repair it?",
    subDay: true,
    packet: "sub-packets",
    kind: "lab",
  },
  {
    id: "lab-8",
    number: 8,
    date: "2026-11-17",
    dateLabel: "Tue Nov 17",
    title: "AI Innovation Challenge",
    shortTitle: "Innovation Challenge",
    mission:
      "Design and prototype an AI solution that is useful, testable, and responsible.",
    exitCheck: "What is your biggest untested assumption or failure mode?",
    subDay: false,
    packet: "innovation-canvas",
    kind: "design",
  },
  {
    id: "lab-9",
    number: 9,
    date: "2026-12-01",
    dateLabel: "Tue Dec 1",
    title: "AI Shark Tank + Red Team Demo Day",
    shortTitle: "Demo Day",
    mission:
      "Demonstrate your prototype, answer a challenge question, and explain your most important Version 2 improvement.",
    exitCheck: "What feedback or evidence most changed your Version 2?",
    subDay: false,
    packet: "innovation-canvas",
    kind: "demo",
  },
];

// Every Tuesday from the first to the last session. Tuesdays with no session
// listed in the course hub are shown on the timeline as open weeks.
export const semesterTuesdays: string[] = [
  "2026-09-15",
  "2026-09-22",
  "2026-09-29",
  "2026-10-06",
  "2026-10-13",
  "2026-10-20",
  "2026-10-27",
  "2026-11-03",
  "2026-11-10",
  "2026-11-17",
  "2026-11-24",
  "2026-12-01",
];

export interface LogPrompt {
  step: number;
  label: string;
  prompt: string;
}

// The six-step AI Engineer Log from the Lab Notebook (same on every lab page).
export const labLogPrompts: LogPrompt[] = [
  {
    step: 1,
    label: "Define",
    prompt: "What are we trying to make, predict, test, or improve?",
  },
  { step: 2, label: "Predict", prompt: "What do you think will happen? Why?" },
  {
    step: 3,
    label: "Build / Model",
    prompt: "What did you train, prompt, design, or prototype?",
  },
  {
    step: 4,
    label: "Test",
    prompt: "What did you test? What changed, and what stayed the same?",
  },
  {
    step: 5,
    label: "Evidence",
    prompt: "Record numbers, examples, failures, or observations.",
  },
  {
    step: 6,
    label: "Improve",
    prompt: "What should Version 2 change, and why?",
  },
];

export interface SubPacket {
  labId: string;
  heading: string;
  dateLabel: string;
  watchFirst?: string; // video id
  open: string; // tool id
  steps: string[];
  evidencePrompts: string[];
}

export const subPackets: SubPacket[] = [
  {
    labId: "lab-3",
    heading: "Rock-Paper-Scissors AI Challenge",
    dateLabel: "September 29",
    open: "teachable-machine",
    steps: [
      "Open Google Teachable Machine and choose Image Project → Standard Image Model.",
      "Create three classes: ROCK, PAPER, SCISSORS.",
      "Collect at least 30 examples of each gesture. Vary hand position and distance. Keep the camera focused on hands.",
      "Train the model.",
      "TEST #1: A partner makes 10 random gestures. Record how many predictions are correct.",
      "Find the gesture with the most mistakes. Add better examples for that class and retrain.",
      "TEST #2: Run 10 more trials.",
      "Complete the evidence statement below and turn it in.",
    ],
    evidencePrompts: [
      "Test #1: _____ / 10",
      "Weakest class: __________________",
      "What we changed: __________________________________________",
      "Test #2: _____ / 10",
      "Our evidence shows the model __________________ because ________________________________.",
    ],
  },
  {
    labId: "lab-7",
    heading: "Background Bias Challenge",
    dateLabel: "November 10",
    watchFirst: "training-data-bias",
    open: "teachable-machine",
    steps: [
      "Watch the short Training Data & Bias video with the class.",
      "Open Google Teachable Machine and choose Image Project → Standard Image Model.",
      "Create two classes: THUMBS UP and THUMBS DOWN.",
      "Train most THUMBS UP examples on a light background and most THUMBS DOWN examples on a dark background.",
      "Train the model, then TEST by switching the backgrounds. Record what happens.",
      "REPAIR IT: collect BOTH gestures across BOTH backgrounds and different positions.",
      "Retrain and retest. Compare the first model with the repaired model.",
      "Complete the evidence statement below and turn it in.",
    ],
    evidencePrompts: [
      "What unintended shortcut did the first model learn? ________________________________",
      "What did your team change? _______________________________________________",
      "What changed after retraining? ____________________________________________",
      "The model was not being “mean.” It learned __________________ because __________________.",
    ],
  },
];

export interface CanvasBox {
  label: string;
  prompt: string;
}

export const innovationCanvas: CanvasBox[] = [
  { label: "User + Need", prompt: "Who has the problem? What are they trying to do?" },
  {
    label: "Input",
    prompt: "What does the system see, hear, read, sense, or receive?",
  },
  {
    label: "Data / Model",
    prompt: "What examples or information would the AI need to learn from?",
  },
  {
    label: "AI Decision",
    prompt: "What does it predict, classify, recommend, or generate?",
  },
  { label: "Output", prompt: "What happens for the user?" },
  {
    label: "Constraints",
    prompt: "Cost, time, privacy, safety, environment, accessibility, etc.",
  },
  {
    label: "Failure Mode",
    prompt: "What could go wrong, or who might the design fail for?",
  },
  {
    label: "Test + Success",
    prompt: "What would you measure to prove it works?",
  },
  { label: "Version 2", prompt: "What will you change after feedback?" },
];

export const canvasDesignRule =
  "Start with a real user need. AI is only useful if it helps meet that need and can be tested.";

export const demoDay = {
  heading: "Red Team + Version 2",
  principle:
    "Strong engineering presentations include limits, evidence, and improvement.",
  story: [
    { minute: 1, focus: "The problem and user" },
    { minute: 2, focus: "How the AI system works" },
    { minute: 3, focus: "Prototype / demo" },
    { minute: 4, focus: "Answer a red-team challenge" },
  ],
  prompts: [
    { label: "The Problem", prompt: "What user need are you solving?" },
    {
      label: "How It Works",
      prompt: "Explain input → data/model → AI decision → output.",
    },
    {
      label: "Your Evidence",
      prompt: "What did you test, observe, compare, or learn?",
    },
    {
      label: "Red Team Question",
      prompt: "What weakness or untested assumption did someone challenge?",
    },
    {
      label: "Version 2",
      prompt: "What is the single most important improvement, and why?",
    },
  ],
};

export interface DownloadItem {
  id: string;
  file: string; // file name under /downloads
  title: string;
  description: string;
  audience: "Students" | "Substitute" | "Everyone";
  usedOn: string[]; // lab ids
  sizeKb: number;
}

export const downloads: DownloadItem[] = [
  {
    id: "course-hub",
    file: "AI_Engineering_Lab_Student_Course_Hub_Fall_2026.docx",
    title: "Student Course Hub",
    description:
      "One-page semester overview: the engineering mindset, AI safety rule, every session's mission, video, tool and exit check, plus the Quick Link Library.",
    audience: "Everyone",
    usedOn: labs.map((l) => l.id),
    sizeKb: 44,
  },
  {
    id: "lab-notebook",
    file: "AI_Engineer_Lab_Notebook_Fall_2026.docx",
    title: "AI Engineer Lab Notebook",
    description:
      "Nine AI Engineer Logs (one per session) with the six-step Define → Predict → Build/Model → Test → Evidence → Improve flow and each session's exit check.",
    audience: "Students",
    usedOn: labs.map((l) => l.id),
    sizeKb: 45,
  },
  {
    id: "sub-packets",
    file: "AI_Engineering_Lab_Sub_Day_Student_Packets_Fall_2026.docx",
    title: "Sub Day Student Packets",
    description:
      "Student missions for both substitute days: the Rock-Paper-Scissors AI Challenge (Sep 29) and the Background Bias Challenge (Nov 10), with steps, camera rule and evidence statements.",
    audience: "Substitute",
    usedOn: ["lab-3", "lab-7"],
    sizeKb: 44,
  },
  {
    id: "innovation-canvas",
    file: "AI_Innovation_Challenge_Student_Canvas_and_Demo_Fall_2026.docx",
    title: "AI Innovation Canvas + Demo Day Sheet",
    description:
      "The nine-box design canvas for the AI Innovation Challenge (Nov 17) and the Red Team + Version 2 presentation sheet for Demo Day (Dec 1).",
    audience: "Students",
    usedOn: ["lab-8", "lab-9"],
    sizeKb: 43,
  },
];

// Suggested pacing for the 45-minute block. These are starting points written
// for this site (not from the class documents) — teachers should adjust them.
export interface PacingBlock {
  label: string;
  minutes: number;
}

export function suggestedPacing(lab: Lab): PacingBlock[] {
  if (lab.kind === "demo") {
    return [
      { label: "Set up demos and red-team roles", minutes: 5 },
      { label: "4-minute team stories (problem, how it works, demo, red-team answer)", minutes: 32 },
      { label: "Version 2 debrief", minutes: 5 },
      { label: "Exit check", minutes: 3 },
    ];
  }
  if (lab.kind === "design") {
    return [
      { label: lab.watch ? "Launch and video" : "Launch and design rule", minutes: 7 },
      { label: "Define the user and need", minutes: 8 },
      { label: "Design input → AI decision → output", minutes: 14 },
      { label: "Constraints, failure mode and test plan", minutes: 10 },
      { label: "Version 2 idea and exit check", minutes: 6 },
    ];
  }
  if (lab.subDay) {
    return [
      { label: lab.watch ? "Watch video, open the tool, hand out packet" : "Open the tool and hand out packet", minutes: 8 },
      { label: "Collect examples and train", minutes: 12 },
      { label: "Test #1 and find the weakest class", minutes: 7 },
      { label: "Improve the data and retrain", minutes: 8 },
      { label: "Test #2", minutes: 5 },
      { label: "Evidence statement and turn-in", minutes: 5 },
    ];
  }
  return [
    { label: lab.watch ? "Launch and video" : "Launch", minutes: 8 },
    { label: "Define and predict", minutes: 5 },
    { label: "Build or model", minutes: 12 },
    { label: "Test and record evidence", minutes: 10 },
    { label: "Improve: plan Version 2", minutes: 6 },
    { label: "Exit check", minutes: 4 },
  ];
}

export function getLab(id: string): Lab | undefined {
  return labs.find((l) => l.id === id);
}

export function getVideo(id: string | undefined): LinkResource | undefined {
  return id ? videos.find((v) => v.id === id) : undefined;
}

export function getTool(id: string | undefined): LinkResource | undefined {
  return id ? tools.find((t) => t.id === id) : undefined;
}

export function getDownload(id: string | undefined): DownloadItem | undefined {
  return id ? downloads.find((d) => d.id === id) : undefined;
}

export function labsUsingVideo(videoId: string): Lab[] {
  return labs.filter((l) => l.watch === videoId);
}

export function labsUsingTool(toolId: string): Lab[] {
  return labs.filter((l) => l.open === toolId);
}

/** Parse an ISO yyyy-mm-dd as a local date (avoids UTC off-by-one). */
export function parseLocalDate(iso: string): Date {
  const [y, m, d] = iso.split("-").map(Number);
  return new Date(y, m - 1, d);
}

/** The next session on or after `today`, or the last session if the term is over. */
export function nextLab(today: Date): { lab: Lab; status: "upcoming" | "today" | "finished" } {
  const start = new Date(today.getFullYear(), today.getMonth(), today.getDate());
  for (const lab of labs) {
    const d = parseLocalDate(lab.date);
    if (d.getTime() === start.getTime()) return { lab, status: "today" };
    if (d.getTime() > start.getTime()) return { lab, status: "upcoming" };
  }
  return { lab: labs[labs.length - 1], status: "finished" };
}
