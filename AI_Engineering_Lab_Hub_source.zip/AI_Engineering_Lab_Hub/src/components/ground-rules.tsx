import { Camera, ShieldCheck, Sparkles } from "lucide-react";
import { classInfo } from "@/data/course";

// The three rules every page can restate: the engineering mindset, the AI
// safety rule and the camera rule — exactly as written in the class documents.
export function GroundRules({ headingId = "rules-heading" }: { headingId?: string }) {
  return (
    <section aria-labelledby={headingId} className="grid gap-4 md:grid-cols-3">
      <h2 id={headingId} className="sr-only">
        Class ground rules
      </h2>
      <div className="rounded-3xl border-l-4 border-primary bg-card p-5">
        <h3 className="flex items-center gap-2 font-semibold">
          <Sparkles className="size-4 text-accent-foreground" aria-hidden="true" /> Our engineering mindset
        </h3>
        <p className="mt-2 text-sm leading-relaxed">{classInfo.mindset}</p>
        <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{classInfo.engineeringThinking}</p>
      </div>
      <div className="rounded-3xl border-l-4 border-info bg-card p-5">
        <h3 className="flex items-center gap-2 font-semibold">
          <ShieldCheck className="size-4 text-info" aria-hidden="true" /> AI safety
        </h3>
        <p className="mt-2 text-sm leading-relaxed">{classInfo.aiSafety}</p>
      </div>
      <div className="rounded-3xl border-l-4 border-marker bg-card p-5">
        <h3 className="flex items-center gap-2 font-semibold">
          <Camera className="size-4 text-marker" aria-hidden="true" /> Camera rule
        </h3>
        <p className="mt-2 text-sm leading-relaxed">{classInfo.cameraRule}</p>
      </div>
    </section>
  );
}
