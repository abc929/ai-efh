import { Link, NavLink, Outlet, useLocation } from "react-router-dom";
import { motion } from "motion/react";
import { Bot } from "lucide-react";
import { Toaster } from "@/components/ui/sonner";
import { routes } from "@/routes";
import { classInfo } from "@/data/course";
import { cn } from "@/lib/utils";

// App shell: skip link, sticky top navigation (mapped over `routes` so the
// router and the nav never drift apart) and the single <main> landmark.
export function AppShell() {
  const { pathname } = useLocation();
  const navRoutes = routes.filter((r) => r.label);
  return (
    <div className="flex min-h-screen flex-col">
      <a
        href="#main-content"
        className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[60] focus:rounded-full focus:bg-primary focus:px-4 focus:py-2 focus:text-sm focus:font-semibold focus:text-primary-foreground focus:outline-hidden focus:ring-2 focus:ring-ring focus:ring-offset-2"
      >
        Skip to main content
      </a>
      <header className="sticky top-0 z-40 border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/80 print:hidden">
        <div className="mx-auto flex w-full max-w-6xl flex-wrap items-center gap-x-6 gap-y-2 px-4 py-3 sm:px-6">
          <Link
            to="/"
            className="flex min-w-0 items-center gap-2.5 rounded-full font-semibold tracking-tight focus-visible:outline-hidden focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
          >
            <span
              className="grid size-9 shrink-0 place-items-center rounded-2xl bg-primary text-primary-foreground"
              aria-hidden="true"
            >
              <Bot className="size-5" />
            </span>
            <span className="flex min-w-0 flex-col leading-tight">
              <span className="truncate">{classInfo.title}</span>
              <span className="truncate text-xs font-normal text-muted-foreground">
                {classInfo.club} · {classInfo.term}
              </span>
            </span>
          </Link>
          <nav
            aria-label="Site sections"
            className="no-scrollbar -mx-1 flex min-w-0 flex-1 basis-full items-center gap-1 overflow-x-auto px-1 py-1 md:basis-auto md:justify-end"
          >
            {navRoutes.map((r) => (
              <NavLink
                key={r.path}
                to={r.path}
                end={r.path === "/"}
                className={({ isActive }) =>
                  cn(
                    "flex shrink-0 items-center gap-1.5 rounded-full px-3 py-1.5 text-sm font-medium transition-colors focus-visible:outline-hidden focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
                    isActive
                      ? "bg-primary text-primary-foreground"
                      : "text-foreground hover:bg-accent hover:text-accent-foreground",
                  )
                }
              >
                {r.icon && <r.icon className="size-4" aria-hidden="true" />}
                {r.label}
              </NavLink>
            ))}
          </nav>
        </div>
      </header>
      <main id="main-content" className="flex flex-1 flex-col" tabIndex={-1}>
        {/* key on pathname → each route re-mounts and replays the entrance. */}
        <motion.div
          key={pathname}
          initial={{ opacity: 0, y: 6 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.15, ease: "easeOut" }}
          className="flex-1"
        >
          <Outlet />
        </motion.div>
      </main>
      <Toaster />
    </div>
  );
}

export default AppShell;
