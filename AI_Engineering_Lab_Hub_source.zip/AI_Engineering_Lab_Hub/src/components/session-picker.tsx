import { CircleCheck } from "lucide-react";
import { NativeSelect, NativeSelectOption } from "@/components/ui/native-select";
import { Label } from "@/components/ui/label";
import { labs } from "@/data/course";
import { cn } from "@/lib/utils";

// Shared session chooser: a compact select on small screens, a vertical list
// of toggle buttons on larger ones. Both drive the same selection.
export function SessionPicker({
  selectedId,
  onSelect,
  taught,
  label = "Choose a session",
  idPrefix,
}: {
  selectedId: string;
  onSelect: (id: string) => void;
  taught?: Record<string, boolean>;
  label?: string;
  idPrefix: string;
}) {
  const selectId = `${idPrefix}-select`;
  return (
    <div className="print:hidden">
      <div className="lg:hidden">
        <Label htmlFor={selectId} className="mb-1.5 block text-sm font-medium">
          {label}
        </Label>
        <NativeSelect
          id={selectId}
          value={selectedId}
          onChange={(e) => onSelect(e.target.value)}
          className="w-full rounded-full"
        >
          {labs.map((lab) => (
            <NativeSelectOption key={lab.id} value={lab.id}>
              Lab {lab.number} · {lab.dateLabel} · {lab.title}
              {lab.subDay ? " (Sub day)" : ""}
            </NativeSelectOption>
          ))}
        </NativeSelect>
      </div>
      <nav aria-label={label} className="hidden lg:block">
        <ol className="sticky top-24 space-y-1">
          {labs.map((lab) => {
            const active = lab.id === selectedId;
            return (
              <li key={lab.id}>
                <button
                  type="button"
                  aria-pressed={active}
                  onClick={() => onSelect(lab.id)}
                  className={cn(
                    "flex w-full items-start gap-3 rounded-2xl px-3 py-2.5 text-left transition-colors focus-visible:outline-hidden focus-visible:ring-2 focus-visible:ring-ring",
                    active ? "bg-primary text-primary-foreground" : "hover:bg-accent hover:text-accent-foreground",
                  )}
                >
                  <span className="mt-0.5 w-6 shrink-0 text-sm font-bold tabular-nums">{lab.number}</span>
                  <span className="min-w-0 flex-1">
                    <span className="block text-xs font-semibold uppercase tracking-wide">
                      {lab.dateLabel}
                      {lab.subDay && " · Sub"}
                    </span>
                    <span className="block text-sm font-medium leading-snug">{lab.title}</span>
                  </span>
                  {taught?.[lab.id] && (
                    <CircleCheck
                      className={cn("mt-1 size-4 shrink-0", active ? "text-primary-foreground" : "text-success")}
                      aria-label="Taught"
                    />
                  )}
                </button>
              </li>
            );
          })}
        </ol>
      </nav>
    </div>
  );
}
