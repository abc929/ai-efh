import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

// Consistent page width, padding and heading block for every section page.
export function PageFrame({
  eyebrow,
  title,
  intro,
  action,
  children,
  className,
}: {
  eyebrow?: ReactNode;
  title: ReactNode;
  intro?: ReactNode;
  action?: ReactNode;
  children: ReactNode;
  className?: string;
}) {
  return (
    <div className={cn("mx-auto w-full max-w-6xl px-4 py-8 sm:px-6 sm:py-10", className)}>
      <div className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div className="max-w-3xl space-y-2">
          {eyebrow && (
            <p className="text-xs font-semibold uppercase tracking-[0.18em] text-accent-foreground">
              {eyebrow}
            </p>
          )}
          <h1 className="text-3xl font-bold tracking-tight sm:text-4xl">{title}</h1>
          {intro && <p className="text-base text-muted-foreground sm:text-lg">{intro}</p>}
        </div>
        {action && <div className="flex shrink-0 flex-wrap gap-2 print:hidden">{action}</div>}
      </div>
      <div className="space-y-10">{children}</div>
    </div>
  );
}
