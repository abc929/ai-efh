import { useId } from "react";
import {
  labs,
  parseLocalDate,
  semesterTuesdays,
  type Lab,
} from "@/data/course";
import { cn } from "@/lib/utils";

// The semester at a glance: one column per Tuesday from the first session to
// Demo Day, with a node on every session date. Position encodes time, the
// node style encodes the kind of day, and a marker shows where "today" falls.
// The SVG is presented as an image; the accessible session list next to it is
// the keyboard/screen-reader equivalent (clicking a node is a mouse shortcut).

const W = 1000;
const H = 300;
const LEFT = 56;
const RIGHT = 56;
const TRACK_Y = 176;
const COLS = semesterTuesdays.length;
const COL_W = (W - LEFT - RIGHT) / (COLS - 1);
const FIRST = parseLocalDate(semesterTuesdays[0]).getTime();
const LAST = parseLocalDate(semesterTuesdays[COLS - 1]).getTime();
const MS_PER_DAY = 86_400_000;

const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

function colX(i: number) {
  return LEFT + i * COL_W;
}

function dateX(d: Date) {
  const days = (d.getTime() - FIRST) / MS_PER_DAY;
  const totalDays = (LAST - FIRST) / MS_PER_DAY;
  const x = LEFT + (days / totalDays) * (W - LEFT - RIGHT);
  return Math.min(Math.max(x, 14), W - 14);
}

function shortDate(iso: string) {
  const d = parseLocalDate(iso);
  return `${MONTHS[d.getMonth()]} ${d.getDate()}`;
}

interface MonthBand {
  label: string;
  from: number;
  to: number;
}

function monthBands(): MonthBand[] {
  const bands: MonthBand[] = [];
  semesterTuesdays.forEach((iso, i) => {
    const m = parseLocalDate(iso).getMonth();
    const label = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"][m];
    const last = bands[bands.length - 1];
    if (last && last.label === label) last.to = i;
    else bands.push({ label, from: i, to: i });
  });
  return bands;
}

export function SemesterTimeline({
  selectedId,
  onSelect,
  taught,
  today,
  className,
}: {
  selectedId: string | null;
  onSelect: (id: string) => void;
  taught: Record<string, boolean>;
  today: Date;
  className?: string;
}) {
  const titleId = useId();
  const descId = useId();
  const byDate = new Map<string, Lab>(labs.map((l) => [l.date, l]));
  const todayX = dateX(new Date(today.getFullYear(), today.getMonth(), today.getDate()));
  const termOver = today.getTime() > LAST + MS_PER_DAY;
  const termNotStarted = today.getTime() < FIRST;

  const description = labs
    .map((l) => `Lab ${l.number}, ${l.dateLabel}: ${l.title}${l.subDay ? " (substitute day)" : ""}`)
    .join(". ");

  return (
    <svg
      viewBox={`0 0 ${W} ${H}`}
      role="img"
      data-timeline=""
      aria-labelledby={`${titleId} ${descId}`}
      className={cn("h-auto w-full select-none", className)}
    >
      <title id={titleId}>Fall 2026 semester timeline of the AI Engineering Lab</title>
      <desc id={descId}>
        Twelve Tuesdays from September 15 to December 1 with nine sessions. {description}. Tuesdays with no
        session are open weeks: October 6, November 3 and November 24.
      </desc>

      {/* Month bands */}
      {monthBands().map((b) => {
        const x1 = colX(b.from) - COL_W / 2 + 4;
        const x2 = colX(b.to) + COL_W / 2 - 4;
        return (
          <g key={b.label}>
            <rect
              x={x1}
              y={14}
              width={x2 - x1}
              height={26}
              rx={13}
              className="fill-accent"
            />
            <text
              x={(x1 + x2) / 2}
              y={32}
              textAnchor="middle"
              fontSize={13}
              fontWeight={600}
              className="fill-accent-foreground"
            >
              {b.label}
            </text>
          </g>
        );
      })}

      {/* Track */}
      <line
        x1={colX(0) - 36}
        x2={colX(COLS - 1) + 36}
        y1={TRACK_Y}
        y2={TRACK_Y}
        strokeWidth={4}
        strokeLinecap="round"
        className="stroke-border"
      />

      {/* Today marker */}
      <g>
        <line
          x1={todayX}
          x2={todayX}
          y1={52}
          y2={258}
          strokeWidth={2}
          strokeDasharray="4 5"
          className="stroke-marker"
        />
        <rect
          x={todayX - 26}
          y={262}
          width={52}
          height={20}
          rx={10}
          className="fill-marker"
        />
        <text x={todayX} y={276} textAnchor="middle" fontSize={11} fontWeight={700} fill="#fff">
          {termNotStarted ? "TODAY" : termOver ? "DONE" : "TODAY"}
        </text>
      </g>

      {/* Columns */}
      {semesterTuesdays.map((iso, i) => {
        const x = colX(i);
        const lab = byDate.get(iso);
        const titleY = i % 2 === 0 ? 126 : 92;
        if (!lab) {
          return (
            <g key={iso}>
              <circle cx={x} cy={TRACK_Y} r={7} strokeWidth={2} className="fill-background stroke-border" />
              <text x={x} y={TRACK_Y + 40} textAnchor="middle" fontSize={12} className="fill-muted-foreground">
                {shortDate(iso)}
              </text>
              <text x={x} y={TRACK_Y + 56} textAnchor="middle" fontSize={10} className="fill-muted-foreground">
                open week
              </text>
            </g>
          );
        }
        const selected = lab.id === selectedId;
        const done = !!taught[lab.id];
        return (
          <g
            key={iso}
            onClick={() => onSelect(lab.id)}
            className="cursor-pointer"
            data-selected={selected ? "true" : undefined}
          >
            {/* connector from title to node */}
            <line
              x1={x}
              x2={x}
              y1={titleY + 8}
              y2={TRACK_Y - 20}
              strokeWidth={1.5}
              className={selected ? "stroke-primary" : "stroke-border"}
            />
            <text
              x={x}
              y={titleY}
              textAnchor="middle"
              fontSize={12.5}
              fontWeight={selected ? 700 : 500}
              className={selected ? "fill-primary" : "fill-foreground"}
            >
              {lab.shortTitle}
            </text>
            {lab.subDay && (
              <text x={x} y={titleY - 15} textAnchor="middle" fontSize={9.5} fontWeight={700} letterSpacing={1} className="fill-info">
                SUB DAY
              </text>
            )}
            {lab.kind === "demo" && (
              <text x={x} y={titleY - 15} textAnchor="middle" fontSize={9.5} fontWeight={700} letterSpacing={1} className="fill-accent-foreground">
                FINAL
              </text>
            )}
            {/* selection halo */}
            {selected && (
              <circle cx={x} cy={TRACK_Y} r={29} strokeWidth={3} className="fill-primary/15 stroke-primary" />
            )}
            {/* node */}
            {lab.subDay ? (
              <circle
                cx={x}
                cy={TRACK_Y}
                r={19}
                strokeWidth={3}
                strokeDasharray="5 4"
                className="fill-card stroke-info"
              />
            ) : lab.kind === "demo" ? (
              <>
                <circle cx={x} cy={TRACK_Y} r={23} strokeWidth={2.5} className="fill-card stroke-primary" />
                <circle cx={x} cy={TRACK_Y} r={17} className="fill-primary" />
              </>
            ) : (
              <circle cx={x} cy={TRACK_Y} r={19} className="fill-primary" />
            )}
            <text
              x={x}
              y={TRACK_Y + 5}
              textAnchor="middle"
              fontSize={14}
              fontWeight={700}
              className={lab.subDay ? "fill-foreground" : "fill-primary-foreground"}
            >
              {lab.number}
            </text>
            {/* taught badge */}
            {done && (
              <g>
                <circle cx={x + 16} cy={TRACK_Y - 16} r={8.5} className="fill-success" />
                <path
                  d={`M ${x + 11.5} ${TRACK_Y - 16} l 3 3 l 6 -6`}
                  fill="none"
                  stroke="#fff"
                  strokeWidth={2.2}
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </g>
            )}
            <text
              x={x}
              y={TRACK_Y + 40}
              textAnchor="middle"
              fontSize={12}
              fontWeight={selected ? 700 : 500}
              className="fill-foreground"
            >
              {shortDate(iso)}
            </text>
          </g>
        );
      })}
    </svg>
  );
}
