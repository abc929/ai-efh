import type { ReactNode } from "react";
import { ExternalLink } from "lucide-react";
import { safeUrl } from "@/lib/safe-url";
import { cn } from "@/lib/utils";

// External link that always opens in a new tab and says so for screen readers.
export function ResourceLink({
  href,
  children,
  className,
  variant = "pill",
}: {
  href: string;
  children: ReactNode;
  className?: string;
  variant?: "pill" | "inline" | "button";
}) {
  const url = safeUrl(href);
  if (!url) return <span className={className}>{children}</span>;
  return (
    <a
      href={url}
      target="_blank"
      rel="noopener noreferrer"
      className={cn(
        "focus-visible:outline-hidden focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
        variant === "pill" &&
          "inline-flex items-center gap-1.5 rounded-full border border-border bg-card px-3 py-1.5 text-sm font-medium text-foreground transition-colors hover:border-primary hover:text-primary",
        variant === "button" &&
          "inline-flex items-center gap-2 rounded-full bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90",
        variant === "inline" && "inline-flex items-center gap-1 font-medium text-primary underline-offset-4 hover:underline",
        className,
      )}
    >
      {children}
      <ExternalLink className="size-3.5 shrink-0" aria-hidden="true" />
      <span className="sr-only"> (opens in a new tab)</span>
    </a>
  );
}
