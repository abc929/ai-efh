import type { ReactElement } from "react";
import {
  BookOpen,
  CalendarDays,
  ClipboardList,
  Download,
  FlaskConical,
  GraduationCap,
  Video,
  type LucideIcon,
} from "lucide-react";
import { HomePage } from "@/pages/home";
import { TeacherGuidesPage } from "@/pages/teacher-guides";
import { StudentResourcesPage } from "@/pages/student-resources";
import { VideosPage } from "@/pages/videos";
import { ExperimentsPage } from "@/pages/experiments";
import { SubPlansPage } from "@/pages/sub-plans";
import { MaterialsPage } from "@/pages/materials";

export interface AppRoute {
  /** "/" is the index route; others are paths under the shell. */
  path: string;
  element: ReactElement;
  /** Optional nav metadata — set these only for routes that should appear in a
   *  navbar/sidebar (the shell maps over `routes` to build its top nav). */
  label?: string;
  icon?: LucideIcon;
}

// Single source of truth for routes. Add a page = add ONE entry here.
// `App.tsx` builds <Routes> from this array and the shell's nav maps over it,
// so the router and the nav can never drift out of sync. `not-found` is wired in App.tsx.
export const routes: AppRoute[] = [
  { path: "/", element: <HomePage />, label: "Schedule", icon: CalendarDays },
  { path: "/teacher-guides", element: <TeacherGuidesPage />, label: "Teacher guides", icon: GraduationCap },
  { path: "/students", element: <StudentResourcesPage />, label: "Students", icon: BookOpen },
  { path: "/videos", element: <VideosPage />, label: "Videos", icon: Video },
  { path: "/experiments", element: <ExperimentsPage />, label: "Experiments", icon: FlaskConical },
  { path: "/sub-plans", element: <SubPlansPage />, label: "Sub plans", icon: ClipboardList },
  { path: "/materials", element: <MaterialsPage />, label: "Downloads", icon: Download },
];
