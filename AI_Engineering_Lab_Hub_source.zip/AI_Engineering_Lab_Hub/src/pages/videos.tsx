import { useState } from "react";
import { Link } from "react-router-dom";
import { Play } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { NativeSelect, NativeSelectOption } from "@/components/ui/native-select";
import { PageFrame } from "@/components/page-frame";
import { ResourceLink } from "@/components/resource-link";
import { labs, labsUsingVideo, videoLibrary, videos } from "@/data/course";
import { useAppStore } from "@/lib/store";

export function VideosPage() {
  const [filter, setFilter] = useState<string>("all");
  const selectLab = useAppStore((s) => s.selectLab);
  const labsWithVideo = labs.filter((l) => l.watch);
  const shown = filter === "all" ? videos : videos.filter((v) => labsUsingVideo(v.id).some((l) => l.id === filter));

  return (
    <PageFrame
      eyebrow="Watch"
      title="Class videos"
      intro="Every video the class watches, matched to the session it belongs to. Links open on YouTube in a new tab."
      action={
        <div className="flex items-center gap-2">
          <Label htmlFor="video-filter" className="text-sm">
            Show
          </Label>
          <NativeSelect id="video-filter" value={filter} onChange={(e) => setFilter(e.target.value)} className="rounded-full">
            <NativeSelectOption value="all">All sessions</NativeSelectOption>
            {labsWithVideo.map((l) => (
              <NativeSelectOption key={l.id} value={l.id}>
                Lab {l.number} · {l.dateLabel} · {l.shortTitle}
              </NativeSelectOption>
            ))}
          </NativeSelect>
        </div>
      }
    >
      <ul className="grid gap-5 md:grid-cols-2" aria-label="Videos">
        {shown.map((v, i) => {
          const used = labsUsingVideo(v.id);
          return (
            <li key={v.id} className="flex flex-col overflow-hidden rounded-3xl border border-border bg-card">
              <div
                className={
                  i % 2 === 0
                    ? "flex h-36 items-center justify-center bg-primary text-primary-foreground"
                    : "flex h-36 items-center justify-center bg-accent text-accent-foreground"
                }
                aria-hidden="true"
              >
                <span className="grid size-16 place-items-center rounded-full border-2 border-current">
                  <Play className="ml-1 size-7" />
                </span>
              </div>
              <div className="flex flex-1 flex-col gap-3 p-5">
                <div>
                  <p className="text-xs font-semibold uppercase tracking-wide text-accent-foreground">{v.source}</p>
                  <h2 className="mt-1 text-xl font-bold tracking-tight">{v.title}</h2>
                </div>
                <div>
                  <p className="text-xs font-semibold uppercase tracking-wide">Used in</p>
                  <ul className="mt-1.5 flex flex-wrap gap-1.5">
                    {used.map((l) => (
                      <li key={l.id}>
                        <Link
                          to="/teacher-guides"
                          onClick={() => selectLab(l.id)}
                          className="rounded-full focus-visible:outline-hidden focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                        >
                          <Badge variant="secondary" className="rounded-full">
                            Lab {l.number} · {l.dateLabel} · {l.shortTitle}
                          </Badge>
                        </Link>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="mt-auto pt-1">
                  <ResourceLink href={v.url} variant="button">
                    <Play className="size-4" aria-hidden="true" /> Watch on YouTube
                  </ResourceLink>
                </div>
              </div>
            </li>
          );
        })}
      </ul>

      <section aria-labelledby="library-heading" className="rounded-3xl border border-border bg-card p-6">
        <h2 id="library-heading" className="text-lg font-semibold tracking-tight">
          Need another explainer?
        </h2>
        <p className="mt-1 text-sm text-muted-foreground">
          The {videoLibrary.title} has the full set of short videos the Code.org clips above come from.
        </p>
        <div className="mt-3">
          <ResourceLink href={videoLibrary.url}>{videoLibrary.title}</ResourceLink>
        </div>
      </section>
    </PageFrame>
  );
}
