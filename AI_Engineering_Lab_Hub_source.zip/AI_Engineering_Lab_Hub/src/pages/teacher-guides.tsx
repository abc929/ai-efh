import { useMemo } from "react";
import { Link } from "react-router-dom";
import {
  Camera,
  CircleCheck,
  ClipboardList,
  Download,
  FlaskConical,
  NotebookPen,
  Play,
  Printer,
  ShieldCheck,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { PageFrame } from "@/components/page-frame";
import { ResourceLink } from "@/components/resource-link";
import { SessionPicker } from "@/components/session-picker";
import {
  canvasDesignRule,
  classInfo,
  demoDay,
  getDownload,
  getLab,
  getTool,
  getVideo,
  labLogPrompts,
  nextLab,
  subPackets,
  suggestedPacing,
} from "@/data/course";
import { downloadHref } from "@/lib/download-href";
import { useAppStore } from "@/lib/store";
import { cn } from "@/lib/utils";

const SEGMENT_COLORS = ["bg-chart-1", "bg-chart-2", "bg-chart-3", "bg-chart-4", "bg-chart-5", "bg-primary"];

function formatClock(totalMinutes: number) {
  const h = Math.floor(totalMinutes / 60);
  const m = totalMinutes % 60;
  return `${h}:${m.toString().padStart(2, "0")}`;
}

export function TeacherGuidesPage() {
  const selectedLabId = useAppStore((s) => s.selectedLabId);
  const selectLab = useAppStore((s) => s.selectLab);
  const taught = useAppStore((s) => s.taught);
  const toggleTaught = useAppStore((s) => s.toggleTaught);
  const teacherNotes = useAppStore((s) => s.teacherNotes);
  const setTeacherNote = useAppStore((s) => s.setTeacherNote);
  const storageAvailable = useAppStore((s) => s.storageAvailable);

  const today = useMemo(() => new Date(), []);
  const lab = getLab(selectedLabId ?? "") ?? nextLab(today).lab;
  const video = getVideo(lab.watch);
  const tool = getTool(lab.open);
  const packet = getDownload(lab.packet);
  const pacing = suggestedPacing(lab);
  const totalMinutes = pacing.reduce((sum, p) => sum + p.minutes, 0);
  const subPacket = subPackets.find((p) => p.labId === lab.id);
  const note = teacherNotes[lab.id] ?? "";
  const isTaught = !!taught[lab.id];

  let clock = 0;
  const schedule = pacing.map((p) => {
    const start = clock;
    clock += p.minutes;
    return { ...p, start, end: clock };
  });

  return (
    <PageFrame
      eyebrow="For the teacher"
      title="Teacher guides"
      intro="One guide per session: the mission, what to open before class, a suggested 45-minute flow, the six-step AI Engineer Log students complete, and the exit check."
      action={
        <Button type="button" variant="outline" className="rounded-full" onClick={() => window.print()}>
          <Printer aria-hidden="true" /> Print this guide
        </Button>
      }
    >
      <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_minmax(0,2.4fr)]">
        <SessionPicker idPrefix="teacher" selectedId={lab.id} onSelect={selectLab} taught={taught} />

        <article aria-labelledby="guide-title" className="space-y-8">
          {/* Header */}
          <header className="rounded-3xl border border-border bg-card p-6 sm:p-8">
            <div className="flex flex-wrap items-center gap-2">
              <Badge className="rounded-full">Lab {lab.number}</Badge>
              <span className="text-sm font-medium">{lab.dateLabel}</span>
              <span className="text-sm text-muted-foreground">· {classInfo.meets}</span>
              {lab.subDay && (
                <Badge variant="outline" className="rounded-full border-info text-foreground">
                  Substitute day
                </Badge>
              )}
              {isTaught && (
                <Badge variant="outline" className="rounded-full border-success text-foreground">
                  <CircleCheck aria-hidden="true" /> Taught
                </Badge>
              )}
            </div>
            <h2 id="guide-title" className="mt-3 text-3xl font-bold tracking-tight">
              {lab.title}
            </h2>
            <p className="mt-1 text-xs font-semibold uppercase tracking-[0.18em] text-accent-foreground">
              Mission
            </p>
            <p className="mt-1 text-lg leading-relaxed">{lab.mission}</p>
            <div className="mt-5 flex flex-wrap gap-2 print:hidden">
              <Button
                type="button"
                variant={isTaught ? "secondary" : "default"}
                aria-pressed={isTaught}
                onClick={() => toggleTaught(lab.id)}
                className="rounded-full"
              >
                <CircleCheck aria-hidden="true" />
                {isTaught ? "Marked taught" : "Mark as taught"}
              </Button>
              {lab.subDay && (
                <Button asChild variant="outline" className="rounded-full">
                  <Link to="/sub-plans">
                    <ClipboardList aria-hidden="true" /> Open the substitute plan
                  </Link>
                </Button>
              )}
            </div>
          </header>

          {/* Before class */}
          <section aria-labelledby="prep-heading" className="space-y-3">
            <h3 id="prep-heading" className="text-lg font-semibold tracking-tight">
              Before class
            </h3>
            <ul className="grid gap-3 sm:grid-cols-2">
              {video && (
                <li className="rounded-2xl border border-border bg-card p-4">
                  <p className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wide">
                    <Play className="size-3.5" aria-hidden="true" /> Queue the video
                  </p>
                  <div className="mt-2">
                    <ResourceLink href={video.url}>
                      {video.title} · {video.source}
                    </ResourceLink>
                  </div>
                </li>
              )}
              {tool && (
                <li className="rounded-2xl border border-border bg-card p-4">
                  <p className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wide">
                    <FlaskConical className="size-3.5" aria-hidden="true" /> Open the tool
                  </p>
                  <div className="mt-2">
                    <ResourceLink href={tool.url}>{lab.openLabel ?? tool.title}</ResourceLink>
                  </div>
                </li>
              )}
              {packet && (
                <li className="rounded-2xl border border-border bg-card p-4">
                  <p className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wide">
                    <Download className="size-3.5" aria-hidden="true" /> Print or share the handout
                  </p>
                  <div className="mt-2">
                    <a
                      href={downloadHref(packet.file)}
                      download
                      className="inline-flex items-center gap-1.5 rounded-full border border-border bg-card px-3 py-1.5 text-sm font-medium transition-colors hover:border-primary hover:text-primary focus-visible:outline-hidden focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                    >
                      <Download className="size-3.5" aria-hidden="true" /> {packet.title}
                    </a>
                  </div>
                </li>
              )}
              <li className="rounded-2xl border border-border bg-card p-4">
                <p className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wide">
                  <NotebookPen className="size-3.5" aria-hidden="true" /> Lab notebook
                </p>
                <p className="mt-2 text-sm">
                  Students use <span className="font-medium">AI Engineer Log {lab.number}</span> in the Lab
                  Notebook, or the digital log on the Students page.
                </p>
              </li>
              {lab.kind === "lab" && lab.number === 6 && (
                <li className="rounded-2xl border border-border bg-card p-4 sm:col-span-2">
                  <p className="text-xs font-semibold uppercase tracking-wide">Costume day</p>
                  <p className="mt-2 text-sm">
                    This session uses costume day to stress-test the pose model under different clothing and
                    environment conditions.
                  </p>
                </li>
              )}
            </ul>
          </section>

          {/* Pacing */}
          <section aria-labelledby="pacing-heading" className="space-y-3">
            <div className="flex flex-wrap items-baseline justify-between gap-2">
              <h3 id="pacing-heading" className="text-lg font-semibold tracking-tight">
                Suggested pacing · {totalMinutes} minutes
              </h3>
              <p className="text-sm text-muted-foreground">
                A starting point written for this site — adjust to your class.
              </p>
            </div>
            <div className="flex h-4 w-full overflow-hidden rounded-full" aria-hidden="true">
              {schedule.map((p, i) => (
                <div
                  key={p.label}
                  className={cn("h-full", SEGMENT_COLORS[i % SEGMENT_COLORS.length])}
                  style={{ flexGrow: p.minutes, flexBasis: 0 }}
                />
              ))}
            </div>
            <ol className="divide-y divide-border rounded-2xl border border-border bg-card">
              {schedule.map((p, i) => (
                <li key={p.label} className="flex items-start gap-3 px-4 py-3">
                  <span
                    className={cn("mt-1.5 size-3 shrink-0 rounded-full", SEGMENT_COLORS[i % SEGMENT_COLORS.length])}
                    aria-hidden="true"
                  />
                  <span className="w-24 shrink-0 text-sm font-semibold tabular-nums">
                    {formatClock(p.start)}–{formatClock(p.end)}
                  </span>
                  <span className="min-w-0 flex-1 text-sm">{p.label}</span>
                  <span className="shrink-0 text-sm text-muted-foreground">{p.minutes} min</span>
                </li>
              ))}
            </ol>
          </section>

          {/* Student flow */}
          <section aria-labelledby="flow-heading" className="space-y-3">
            <h3 id="flow-heading" className="text-lg font-semibold tracking-tight">
              {subPacket ? "Student packet steps" : lab.kind === "demo" ? "Demo Day format" : "Student lab log"}
            </h3>
            {subPacket ? (
              <ol className="space-y-2">
                {subPacket.steps.map((step, i) => (
                  <li key={step} className="flex gap-3 rounded-2xl border border-border bg-card px-4 py-3">
                    <span className="grid size-7 shrink-0 place-items-center rounded-full bg-primary text-sm font-bold text-primary-foreground">
                      {i + 1}
                    </span>
                    <span className="text-sm leading-relaxed">{step}</span>
                  </li>
                ))}
              </ol>
            ) : lab.kind === "demo" ? (
              <div className="space-y-3">
                <p className="text-sm">{demoDay.principle}</p>
                <ol className="grid gap-2 sm:grid-cols-2">
                  {demoDay.story.map((s) => (
                    <li key={s.minute} className="rounded-2xl border border-border bg-card px-4 py-3">
                      <span className="text-xs font-semibold uppercase tracking-wide">Minute {s.minute}</span>
                      <p className="mt-1 text-sm font-medium">{s.focus}</p>
                    </li>
                  ))}
                </ol>
                <ul className="space-y-2">
                  {demoDay.prompts.map((p) => (
                    <li key={p.label} className="rounded-2xl border border-border bg-card px-4 py-3">
                      <span className="text-xs font-semibold uppercase tracking-wide text-accent-foreground">
                        {p.label}
                      </span>
                      <p className="mt-1 text-sm">{p.prompt}</p>
                    </li>
                  ))}
                </ul>
              </div>
            ) : (
              <div className="space-y-3">
                {lab.kind === "design" && lab.number === 8 && (
                  <p className="rounded-2xl bg-accent px-4 py-3 text-sm font-medium text-accent-foreground">
                    Design rule: {canvasDesignRule}
                  </p>
                )}
                <ol className="grid gap-2 sm:grid-cols-2">
                  {labLogPrompts.map((p) => (
                    <li key={p.step} className="rounded-2xl border border-border bg-card px-4 py-3">
                      <span className="text-xs font-semibold uppercase tracking-wide text-accent-foreground">
                        {p.step}. {p.label}
                      </span>
                      <p className="mt-1 text-sm">{p.prompt}</p>
                    </li>
                  ))}
                </ol>
              </div>
            )}
          </section>

          {/* Exit check + rules */}
          <section aria-labelledby="exit-heading" className="grid gap-4 md:grid-cols-[1.2fr_1fr]">
            <div className="rounded-3xl border-l-4 border-primary bg-accent p-5">
              <h3 id="exit-heading" className="text-xs font-semibold uppercase tracking-[0.18em] text-accent-foreground">
                Exit check
              </h3>
              <p className="mt-2 text-lg font-medium">{lab.exitCheck}</p>
            </div>
            <div className="space-y-3 rounded-3xl border border-border bg-card p-5">
              <p className="flex items-center gap-2 text-sm font-semibold">
                <ShieldCheck className="size-4 text-info" aria-hidden="true" /> AI safety
              </p>
              <p className="text-sm leading-relaxed">{classInfo.aiSafety}</p>
              {(tool || lab.subDay) && (
                <>
                  <p className="flex items-center gap-2 text-sm font-semibold">
                    <Camera className="size-4 text-marker" aria-hidden="true" /> Camera rule
                  </p>
                  <p className="text-sm leading-relaxed">{classInfo.cameraRule}</p>
                </>
              )}
            </div>
          </section>

          {/* Notes */}
          <section aria-labelledby="notes-heading" className="space-y-2">
            <div className="flex flex-wrap items-baseline justify-between gap-2">
              <Label htmlFor={`notes-${lab.id}`} id="notes-heading" className="text-lg font-semibold tracking-tight">
                My notes for Lab {lab.number}
              </Label>
              <p className="text-xs text-muted-foreground">
                {storageAvailable ? "Saved automatically on this device." : "Kept for this visit only."}
              </p>
            </div>
            <Textarea
              id={`notes-${lab.id}`}
              value={note}
              onChange={(e) => setTeacherNote(lab.id, e.target.value)}
              placeholder="Reminders, groupings, what worked last time, adjustments to the pacing…"
              rows={5}
              className="rounded-2xl bg-card"
            />
          </section>
        </article>
      </div>
    </PageFrame>
  );
}
