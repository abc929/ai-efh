import { Link } from "react-router-dom";
import { Camera, Download, FlaskConical, Play, Printer, ShieldCheck } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { PageFrame } from "@/components/page-frame";
import { ResourceLink } from "@/components/resource-link";
import { classInfo, getDownload, getLab, getTool, getVideo, subPackets } from "@/data/course";
import { downloadHref } from "@/lib/download-href";

export function SubPlansPage() {
  const packetDoc = getDownload("sub-packets");
  const notebook = getDownload("lab-notebook");

  return (
    <PageFrame
      eyebrow="For a substitute"
      title="Substitute plans"
      intro={`Everything a substitute needs for the two sub days. ${classInfo.club} meets ${classInfo.meets}; students are ${classInfo.ages.toLowerCase()}.`}
      action={
        <>
          {packetDoc && (
            <Button asChild className="rounded-full">
              <a href={downloadHref(packetDoc.file)} download>
                <Download aria-hidden="true" /> Download the student packets
              </a>
            </Button>
          )}
          <Button type="button" variant="outline" className="rounded-full" onClick={() => window.print()}>
            <Printer aria-hidden="true" /> Print
          </Button>
        </>
      }
    >
      {/* Overview for the substitute */}
      <section aria-labelledby="sub-overview" className="grid gap-4 lg:grid-cols-[1.3fr_1fr]">
        <div className="rounded-3xl bg-primary p-6 text-primary-foreground sm:p-8">
          <h2 id="sub-overview" className="text-xs font-semibold uppercase tracking-[0.2em]">
            How a sub day runs
          </h2>
          <p className="mt-3 text-2xl font-bold tracking-tight">{classInfo.subDayJob}</p>
          <ol className="mt-5 space-y-2 text-sm leading-relaxed">
            <li className="flex gap-3">
              <span className="font-bold">1.</span> Open the experiment link on the class display (and play the video first on Nov 10).
            </li>
            <li className="flex gap-3">
              <span className="font-bold">2.</span> Hand out the student packet for the day — the steps and evidence statement are on it.
            </li>
            <li className="flex gap-3">
              <span className="font-bold">3.</span> Students train, test, find the weakness, improve, and test again in teams.
            </li>
            <li className="flex gap-3">
              <span className="font-bold">4.</span> Collect the completed evidence statements — students turn them in at the end.
            </li>
          </ol>
        </div>
        <div className="space-y-4">
          <div className="rounded-3xl border-l-4 border-info bg-card p-5">
            <h3 className="flex items-center gap-2 font-semibold">
              <ShieldCheck className="size-4 text-info" aria-hidden="true" /> AI safety
            </h3>
            <p className="mt-2 text-sm leading-relaxed">{classInfo.aiSafety}</p>
          </div>
          <div className="rounded-3xl border-l-4 border-marker bg-card p-5">
            <h3 className="flex items-center gap-2 font-semibold">
              <Camera className="size-4 text-marker" aria-hidden="true" /> Camera rule
            </h3>
            <p className="mt-2 text-sm leading-relaxed">{classInfo.cameraRule}</p>
          </div>
        </div>
      </section>

      <nav aria-label="Jump to a sub day" className="flex flex-wrap gap-2 print:hidden">
        {subPackets.map((p) => (
          <a
            key={p.labId}
            href={`#${p.labId}`}
            className="rounded-full border border-border bg-card px-3 py-1.5 text-sm font-medium transition-colors hover:border-primary hover:text-primary focus-visible:outline-hidden focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
          >
            {p.dateLabel}: {p.heading}
          </a>
        ))}
      </nav>

      {/* Each sub day */}
      {subPackets.map((p) => {
        const lab = getLab(p.labId);
        const video = getVideo(p.watchFirst);
        const tool = getTool(p.open);
        if (!lab) return null;
        return (
          <article
            key={p.labId}
            id={p.labId}
            aria-labelledby={`sub-${p.labId}`}
            className="scroll-mt-28 rounded-3xl border border-border bg-card p-6 sm:p-8"
          >
            <div className="flex flex-wrap items-center gap-2">
              <Badge className="rounded-full">Lab {lab.number}</Badge>
              <span className="text-sm font-medium">{lab.dateLabel}</span>
              <Badge variant="outline" className="rounded-full border-info text-foreground">
                Sub day
              </Badge>
            </div>
            <h2 id={`sub-${p.labId}`} className="mt-3 text-3xl font-bold tracking-tight">
              {p.heading}
            </h2>
            <p className="mt-1 text-xs font-semibold uppercase tracking-[0.18em] text-accent-foreground">
              Student mission
            </p>
            <p className="mt-1 text-lg leading-relaxed">{lab.mission}</p>

            <div className="mt-5 grid gap-3 sm:grid-cols-2">
              {video && (
                <div className="rounded-2xl bg-muted/60 p-4">
                  <p className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wide">
                    <Play className="size-3.5" aria-hidden="true" /> Watch first
                  </p>
                  <div className="mt-2">
                    <ResourceLink href={video.url}>
                      {video.title} · {video.source}
                    </ResourceLink>
                  </div>
                </div>
              )}
              {tool && (
                <div className="rounded-2xl bg-muted/60 p-4">
                  <p className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wide">
                    <FlaskConical className="size-3.5" aria-hidden="true" /> Open the experiment
                  </p>
                  <div className="mt-2">
                    <ResourceLink href={tool.url}>{tool.title}</ResourceLink>
                  </div>
                </div>
              )}
            </div>

            <div className="mt-6 grid gap-6 lg:grid-cols-[1.4fr_1fr]">
              <div>
                <h3 className="text-sm font-semibold uppercase tracking-wide">Steps students follow</h3>
                <ol className="mt-3 space-y-2">
                  {p.steps.map((step, i) => (
                    <li key={step} className="flex gap-3 rounded-2xl border border-border bg-background px-4 py-3 text-sm leading-relaxed">
                      <span className="grid size-7 shrink-0 place-items-center rounded-full bg-primary text-sm font-bold text-primary-foreground">
                        {i + 1}
                      </span>
                      <span>{step}</span>
                    </li>
                  ))}
                </ol>
              </div>
              <div className="space-y-4">
                <div>
                  <h3 className="text-sm font-semibold uppercase tracking-wide">Evidence statement (on the packet)</h3>
                  <ul className="mt-3 space-y-2">
                    {p.evidencePrompts.map((e) => (
                      <li key={e} className="rounded-2xl border border-dashed border-border bg-background px-4 py-3 text-sm">
                        {e}
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="rounded-2xl border-l-4 border-primary bg-accent p-4">
                  <p className="text-xs font-semibold uppercase tracking-[0.18em] text-accent-foreground">Exit check</p>
                  <p className="mt-1 font-medium">{lab.exitCheck}</p>
                </div>
              </div>
            </div>

            <div className="mt-6 flex flex-wrap gap-2 print:hidden">
              {packetDoc && (
                <Button asChild variant="outline" className="rounded-full">
                  <a href={downloadHref(packetDoc.file)} download>
                    <Download aria-hidden="true" /> Student packet (both sub days)
                  </a>
                </Button>
              )}
              {notebook && (
                <Button asChild variant="ghost" className="rounded-full">
                  <a href={downloadHref(notebook.file)} download>
                    <Download aria-hidden="true" /> Lab Notebook
                  </a>
                </Button>
              )}
              <Button asChild variant="ghost" className="rounded-full">
                <Link to="/experiments">See the experiment page</Link>
              </Button>
            </div>
          </article>
        );
      })}
    </PageFrame>
  );
}
