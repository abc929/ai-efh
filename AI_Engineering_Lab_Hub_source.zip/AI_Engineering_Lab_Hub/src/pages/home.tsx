import { useMemo } from "react";
import { Link } from "react-router-dom";
import {
  ArrowRight,
  BookOpen,
  CircleCheck,
  ClipboardList,
  Download,
  FlaskConical,
  GraduationCap,
  Play,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { GroundRules } from "@/components/ground-rules";
import { SemesterTimeline } from "@/components/semester-timeline";
import { ResourceLink } from "@/components/resource-link";
import {
  classInfo,
  engineeringCycle,
  getDownload,
  getLab,
  getTool,
  getVideo,
  labs,
  nextLab,
} from "@/data/course";
import { downloadHref } from "@/lib/download-href";
import { useAppStore } from "@/lib/store";
import { cn } from "@/lib/utils";

export function HomePage() {
  const selectedLabId = useAppStore((s) => s.selectedLabId);
  const selectLab = useAppStore((s) => s.selectLab);
  const taught = useAppStore((s) => s.taught);
  const toggleTaught = useAppStore((s) => s.toggleTaught);

  const today = useMemo(() => new Date(), []);
  const next = useMemo(() => nextLab(today), [today]);
  const selected = getLab(selectedLabId ?? "") ?? next.lab;
  const video = getVideo(selected.watch);
  const tool = getTool(selected.open);
  const packet = getDownload(selected.packet);
  const taughtCount = labs.filter((l) => taught[l.id]).length;
  const isTaught = !!taught[selected.id];

  const nextLabel =
    next.status === "today"
      ? "Today's session"
      : next.status === "finished"
        ? "Final session"
        : "Next session";

  return (
    <div className="mx-auto w-full max-w-6xl px-4 py-6 sm:px-6 sm:py-8">
      <div className="space-y-8">
        {/* Hero */}
        <section className="rounded-[2rem] bg-primary px-6 py-8 text-primary-foreground sm:px-10 sm:py-12">
          <div className="grid gap-8 lg:grid-cols-[1.25fr_1fr] lg:items-end">
            <div className="space-y-4">
              <p className="text-xs font-semibold uppercase tracking-[0.2em]">
                {classInfo.club} · {classInfo.ages} · {classInfo.meets} · {classInfo.term}
              </p>
              <h1 className="text-4xl font-bold leading-[1.05] tracking-tight sm:text-5xl lg:text-6xl">
                {classInfo.title}
              </h1>
              <p className="text-xl font-semibold sm:text-2xl">{classInfo.tagline}</p>
              <p className="max-w-xl text-base leading-relaxed">{classInfo.mindset}</p>
            </div>
            <div className="rounded-3xl bg-background p-5 text-foreground shadow-sm sm:p-6">
              <p className="text-xs font-semibold uppercase tracking-[0.18em] text-accent-foreground">
                {nextLabel}
              </p>
              <p className="mt-2 text-sm font-medium">
                {next.lab.dateLabel} · Lab {next.lab.number}
                {next.lab.subDay && " · Sub day"}
              </p>
              <h2 className="mt-1 text-2xl font-bold tracking-tight">{next.lab.title}</h2>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{next.lab.mission}</p>
              <div className="mt-4 flex flex-wrap gap-2">
                <Button asChild className="rounded-full">
                  <Link to="/teacher-guides" onClick={() => selectLab(next.lab.id)}>
                    <GraduationCap aria-hidden="true" />
                    Teacher guide
                  </Link>
                </Button>
                <Button asChild variant="outline" className="rounded-full">
                  <Link to="/students" onClick={() => selectLab(next.lab.id)}>
                    <BookOpen aria-hidden="true" />
                    Student mission
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Engineering cycle */}
        <ol
          aria-label="Engineering cycle"
          className="flex flex-wrap items-center gap-2 text-sm font-medium"
        >
          {engineeringCycle.map((step, i) => (
            <li key={step} className="flex items-center gap-2">
              <span className="rounded-full border border-border bg-card px-3 py-1">
                <span className="mr-1.5 text-accent-foreground">{i + 1}</span>
                {step}
              </span>
              {i < engineeringCycle.length - 1 && (
                <ArrowRight className="size-4 text-muted-foreground" aria-hidden="true" />
              )}
            </li>
          ))}
        </ol>

        {/* Timeline */}
        <figure className="rounded-[2rem] border border-border bg-card p-4 sm:p-6">
          <div className="flex flex-wrap items-baseline justify-between gap-2 px-2">
            <h2 className="text-lg font-semibold tracking-tight">Semester at a glance</h2>
            <p className="text-sm font-medium">
              {taughtCount} of {labs.length} sessions marked taught
            </p>
          </div>
          <div className="no-scrollbar -mx-2 overflow-x-auto px-2">
            <SemesterTimeline
              selectedId={selected.id}
              onSelect={selectLab}
              taught={taught}
              today={today}
              className="mt-2 min-w-[720px]"
            />
          </div>
          <figcaption className="px-2 text-sm text-muted-foreground">
            Nine Tuesday sessions from Sep 15 to Dec 1, 2026. Two are substitute days (Sep 29 and
            Nov 10) and the term ends with Demo Day. Open weeks have no session listed. Choose a
            session below to see its mission, video, tool and exit check.
          </figcaption>
          <ul className="mt-3 flex flex-wrap gap-x-5 gap-y-2 px-2 text-xs font-medium" aria-label="Timeline legend">
            <li className="flex items-center gap-2">
              <span className="size-3.5 rounded-full bg-primary" aria-hidden="true" /> Lab session
            </li>
            <li className="flex items-center gap-2">
              <span className="size-3.5 rounded-full border-2 border-dashed border-info" aria-hidden="true" />{" "}
              Substitute day
            </li>
            <li className="flex items-center gap-2">
              <span className="size-3.5 rounded-full border-2 border-primary" aria-hidden="true" /> Demo Day
            </li>
            <li className="flex items-center gap-2">
              <span className="size-3.5 rounded-full bg-success" aria-hidden="true" /> Marked taught
            </li>
            <li className="flex items-center gap-2">
              <span className="h-3.5 w-0.5 bg-marker" aria-hidden="true" /> Today
            </li>
          </ul>
        </figure>

        {/* Sessions + detail */}
        <section
          aria-labelledby="sessions-heading"
          className="grid gap-6 lg:grid-cols-[minmax(0,2fr)_minmax(0,3fr)]"
        >
          <div>
            <h2 id="sessions-heading" className="mb-3 text-lg font-semibold tracking-tight">
              Lesson schedule
            </h2>
            <ol className="divide-y divide-border overflow-hidden rounded-3xl border border-border bg-card">
              {labs.map((lab) => {
                const active = lab.id === selected.id;
                return (
                  <li key={lab.id}>
                    <button
                      type="button"
                      aria-pressed={active}
                      onClick={() => selectLab(lab.id)}
                      className={cn(
                        "flex w-full items-center gap-3 px-4 py-3 text-left transition-colors focus-visible:outline-hidden focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-ring",
                        active ? "bg-accent" : "hover:bg-muted/60",
                      )}
                    >
                      <span
                        className={cn(
                          "grid size-9 shrink-0 place-items-center rounded-full text-sm font-bold",
                          lab.subDay
                            ? "border-2 border-dashed border-info text-foreground"
                            : "bg-primary text-primary-foreground",
                        )}
                        aria-hidden="true"
                      >
                        {lab.number}
                      </span>
                      <span className="min-w-0 flex-1">
                        <span className="block text-xs font-semibold uppercase tracking-wide">
                          {lab.dateLabel}
                          {lab.subDay && " · Sub day"}
                        </span>
                        <span className="block font-medium leading-snug">{lab.title}</span>
                      </span>
                      {taught[lab.id] && (
                        <CircleCheck className="size-5 shrink-0 text-success" aria-label="Taught" />
                      )}
                    </button>
                  </li>
                );
              })}
            </ol>
          </div>

          <article
            aria-live="polite"
            aria-labelledby="selected-lab-title"
            className="flex flex-col gap-5 rounded-3xl border border-border bg-card p-5 sm:p-7"
          >
            <div className="flex flex-wrap items-center gap-2">
              <Badge className="rounded-full">Lab {selected.number}</Badge>
              <span className="text-sm font-medium">{selected.dateLabel}</span>
              {selected.subDay && (
                <Badge variant="outline" className="rounded-full border-info text-foreground">
                  Substitute day
                </Badge>
              )}
              {selected.kind === "design" && (
                <Badge variant="secondary" className="rounded-full">
                  Design session
                </Badge>
              )}
              {selected.kind === "demo" && (
                <Badge variant="secondary" className="rounded-full">
                  Demo Day
                </Badge>
              )}
              {isTaught && (
                <Badge variant="outline" className="rounded-full border-success text-foreground">
                  <CircleCheck aria-hidden="true" /> Taught
                </Badge>
              )}
            </div>
            <div>
              <h3 id="selected-lab-title" className="text-2xl font-bold tracking-tight sm:text-3xl">
                {selected.title}
              </h3>
              <p className="mt-1 text-xs font-semibold uppercase tracking-[0.18em] text-accent-foreground">
                Today's mission
              </p>
              <p className="mt-1 text-base leading-relaxed sm:text-lg">{selected.mission}</p>
            </div>

            <dl className="grid gap-3 sm:grid-cols-2">
              <div className="rounded-2xl bg-muted/60 p-4">
                <dt className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wide">
                  <Play className="size-3.5" aria-hidden="true" /> Watch
                </dt>
                <dd className="mt-2">
                  {video ? (
                    <ResourceLink href={video.url}>
                      {video.title} · {video.source}
                    </ResourceLink>
                  ) : (
                    <span className="text-sm">No video for this session.</span>
                  )}
                </dd>
              </div>
              <div className="rounded-2xl bg-muted/60 p-4">
                <dt className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wide">
                  <FlaskConical className="size-3.5" aria-hidden="true" /> Open
                </dt>
                <dd className="mt-2">
                  {tool ? (
                    <ResourceLink href={tool.url}>{selected.openLabel ?? tool.title}</ResourceLink>
                  ) : (
                    <span className="text-sm">No online tool — this is a design or presentation session.</span>
                  )}
                </dd>
              </div>
            </dl>

            <div className="rounded-2xl border-l-4 border-primary bg-accent p-4">
              <p className="text-xs font-semibold uppercase tracking-[0.18em] text-accent-foreground">
                Exit check
              </p>
              <p className="mt-1 font-medium">{selected.exitCheck}</p>
            </div>

            <div className="mt-auto flex flex-wrap gap-2 pt-1">
              <Button
                type="button"
                variant={isTaught ? "secondary" : "outline"}
                aria-pressed={isTaught}
                onClick={() => toggleTaught(selected.id)}
                className="rounded-full"
              >
                <CircleCheck aria-hidden="true" />
                {isTaught ? "Marked taught" : "Mark as taught"}
              </Button>
              <Button asChild variant="outline" className="rounded-full">
                <Link to="/teacher-guides" onClick={() => selectLab(selected.id)}>
                  <GraduationCap aria-hidden="true" /> Teacher guide
                </Link>
              </Button>
              {selected.subDay && (
                <Button asChild variant="outline" className="rounded-full">
                  <Link to="/sub-plans">
                    <ClipboardList aria-hidden="true" /> Substitute plan
                  </Link>
                </Button>
              )}
              {packet && (
                <Button asChild variant="ghost" className="rounded-full">
                  <a href={downloadHref(packet.file)} download>
                    <Download aria-hidden="true" /> {packet.title}
                  </a>
                </Button>
              )}
            </div>
          </article>
        </section>

        <GroundRules />
      </div>
    </div>
  );
}
