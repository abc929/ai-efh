import { useMemo } from "react";
import { Link } from "react-router-dom";
import { Download, FlaskConical, NotebookPen, Play, Printer, Trash2, Video } from "lucide-react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { GroundRules } from "@/components/ground-rules";
import { PageFrame } from "@/components/page-frame";
import { ResourceLink } from "@/components/resource-link";
import { SessionPicker } from "@/components/session-picker";
import { useConfirm } from "@/hooks/use-confirm";
import {
  canvasDesignRule,
  classInfo,
  demoDay,
  getDownload,
  getLab,
  getTool,
  getVideo,
  innovationCanvas,
  labLogPrompts,
  nextLab,
  tools,
  videoLibrary,
  videos,
} from "@/data/course";
import { downloadHref } from "@/lib/download-href";
import { useAppStore } from "@/lib/store";

export function StudentResourcesPage() {
  const selectedLabId = useAppStore((s) => s.selectedLabId);
  const selectLab = useAppStore((s) => s.selectLab);
  const labLogs = useAppStore((s) => s.labLogs);
  const updateLabLog = useAppStore((s) => s.updateLabLog);
  const clearLabLog = useAppStore((s) => s.clearLabLog);
  const storageAvailable = useAppStore((s) => s.storageAvailable);
  const confirm = useConfirm();

  const today = useMemo(() => new Date(), []);
  const lab = getLab(selectedLabId ?? "") ?? nextLab(today).lab;
  const video = getVideo(lab.watch);
  const tool = getTool(lab.open);
  const packet = getDownload(lab.packet);
  const notebook = getDownload("lab-notebook");
  const canvasDoc = getDownload("innovation-canvas");
  const draft = labLogs[lab.id];
  const answers = draft?.answers ?? {};
  const filled = labLogPrompts.filter((p) => (answers[p.step] ?? "").trim().length > 0).length;

  async function handleClear() {
    const ok = await confirm({
      title: `Clear your log for Lab ${lab.number}?`,
      description: "This erases the answers you typed for this session on this device.",
      confirmLabel: "Clear log",
      destructive: true,
    });
    if (ok) {
      clearLabLog(lab.id);
      toast("Log cleared");
    }
  }

  return (
    <PageFrame
      eyebrow="For students"
      title="Student resources"
      intro="Your mission for each session, the rules we follow, the quick links, and a digital AI Engineer Log you can fill in and print."
    >
      <GroundRules headingId="student-rules" />

      {/* Mission */}
      <section aria-labelledby="mission-heading" className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_minmax(0,2.4fr)]">
        <div className="space-y-3">
          <h2 id="mission-heading" className="text-lg font-semibold tracking-tight">
            Pick your session
          </h2>
          <SessionPicker idPrefix="student" selectedId={lab.id} onSelect={selectLab} label="Pick your session" />
        </div>
        <div className="space-y-6">
          <article aria-labelledby="student-mission-title" className="rounded-3xl border border-border bg-card p-6 sm:p-8">
            <div className="flex flex-wrap items-center gap-2">
              <Badge className="rounded-full">Lab {lab.number}</Badge>
              <span className="text-sm font-medium">{lab.dateLabel}</span>
              {lab.subDay && (
                <Badge variant="outline" className="rounded-full border-info text-foreground">
                  Sub day
                </Badge>
              )}
            </div>
            <h3 id="student-mission-title" className="mt-3 text-3xl font-bold tracking-tight">
              {lab.title}
            </h3>
            <p className="mt-1 text-xs font-semibold uppercase tracking-[0.18em] text-accent-foreground">
              Today's mission
            </p>
            <p className="mt-1 text-lg leading-relaxed">{lab.mission}</p>
            <div className="mt-5 grid gap-3 sm:grid-cols-2">
              <div className="rounded-2xl bg-muted/60 p-4">
                <p className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wide">
                  <Play className="size-3.5" aria-hidden="true" /> Watch
                </p>
                <div className="mt-2">
                  {video ? (
                    <ResourceLink href={video.url}>
                      {video.title} · {video.source}
                    </ResourceLink>
                  ) : (
                    <span className="text-sm">No video today.</span>
                  )}
                </div>
              </div>
              <div className="rounded-2xl bg-muted/60 p-4">
                <p className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wide">
                  <FlaskConical className="size-3.5" aria-hidden="true" /> Open
                </p>
                <div className="mt-2">
                  {tool ? (
                    <ResourceLink href={tool.url}>{lab.openLabel ?? tool.title}</ResourceLink>
                  ) : (
                    <span className="text-sm">No online tool today — bring your ideas.</span>
                  )}
                </div>
              </div>
            </div>
            <div className="mt-4 rounded-2xl border-l-4 border-primary bg-accent p-4">
              <p className="text-xs font-semibold uppercase tracking-[0.18em] text-accent-foreground">Exit check</p>
              <p className="mt-1 font-medium">{lab.exitCheck}</p>
            </div>
            {packet && (
              <div className="mt-4 print:hidden">
                <a
                  href={downloadHref(packet.file)}
                  download
                  className="inline-flex items-center gap-1.5 rounded-full border border-border bg-card px-3 py-1.5 text-sm font-medium transition-colors hover:border-primary hover:text-primary focus-visible:outline-hidden focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                >
                  <Download className="size-3.5" aria-hidden="true" /> Download today's handout: {packet.title}
                </a>
              </div>
            )}
          </article>

          {/* Digital lab log */}
          <section aria-labelledby="log-heading" className="rounded-3xl border border-border bg-card p-6 sm:p-8">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <h3 id="log-heading" className="flex items-center gap-2 text-xl font-bold tracking-tight">
                  <NotebookPen className="size-5 text-accent-foreground" aria-hidden="true" />
                  AI Engineer Log {lab.number}
                </h3>
                <p className="mt-1 text-sm text-muted-foreground">
                  {classInfo.tagline} {filled} of {labLogPrompts.length} steps filled in.{" "}
                  {storageAvailable ? "Saved automatically on this device." : "Kept for this visit only."}
                </p>
              </div>
              <div className="flex flex-wrap gap-2 print:hidden">
                <Button type="button" variant="outline" className="rounded-full" onClick={() => window.print()}>
                  <Printer aria-hidden="true" /> Print
                </Button>
                <Button
                  type="button"
                  variant="ghost"
                  className="rounded-full"
                  onClick={handleClear}
                  disabled={!draft}
                >
                  <Trash2 aria-hidden="true" /> Clear
                </Button>
              </div>
            </div>

            <form className="mt-5 space-y-4" onSubmit={(e) => e.preventDefault()}>
              <div className="max-w-sm">
                <Label htmlFor={`log-name-${lab.id}`} className="mb-1.5 block">
                  Name
                </Label>
                <Input
                  id={`log-name-${lab.id}`}
                  value={draft?.studentName ?? ""}
                  onChange={(e) => updateLabLog(lab.id, { studentName: e.target.value })}
                  placeholder="Your name"
                  className="rounded-full bg-background"
                />
              </div>
              <ol className="grid gap-4 md:grid-cols-2">
                {labLogPrompts.map((p) => {
                  const id = `log-${lab.id}-${p.step}`;
                  return (
                    <li key={p.step} className="space-y-1.5">
                      <Label htmlFor={id} className="flex flex-col items-start gap-0.5">
                        <span className="text-xs font-semibold uppercase tracking-wide text-accent-foreground">
                          {p.step}. {p.label}
                        </span>
                        <span className="text-sm font-normal">{p.prompt}</span>
                      </Label>
                      <Textarea
                        id={id}
                        rows={3}
                        value={answers[p.step] ?? ""}
                        onChange={(e) => updateLabLog(lab.id, { answers: { [p.step]: e.target.value } })}
                        className="rounded-2xl bg-background"
                      />
                    </li>
                  );
                })}
              </ol>
              <div className="space-y-1.5 rounded-2xl border-l-4 border-primary bg-accent p-4">
                <Label htmlFor={`log-exit-${lab.id}`} className="flex flex-col items-start gap-0.5">
                  <span className="text-xs font-semibold uppercase tracking-[0.18em] text-accent-foreground">
                    Exit check
                  </span>
                  <span className="text-sm font-medium">{lab.exitCheck}</span>
                </Label>
                <Textarea
                  id={`log-exit-${lab.id}`}
                  rows={2}
                  value={draft?.exitAnswer ?? ""}
                  onChange={(e) => updateLabLog(lab.id, { exitAnswer: e.target.value })}
                  className="rounded-2xl bg-background"
                />
              </div>
            </form>
            {notebook && (
              <p className="mt-4 text-sm text-muted-foreground print:hidden">
                Prefer paper?{" "}
                <a
                  href={downloadHref(notebook.file)}
                  download
                  className="font-medium text-primary underline-offset-4 hover:underline"
                >
                  Download the AI Engineer Lab Notebook
                </a>{" "}
                with all nine logs.
              </p>
            )}
          </section>
        </div>
      </section>

      {/* Quick links */}
      <section aria-labelledby="links-heading" className="space-y-4">
        <div>
          <h2 id="links-heading" className="text-lg font-semibold tracking-tight">
            Quick Link Library
          </h2>
          <p className="text-sm text-muted-foreground">Use this if you need to reopen a class tool or video.</p>
        </div>
        <div className="grid gap-4 md:grid-cols-2">
          <div className="rounded-3xl border border-border bg-card p-5">
            <h3 className="flex items-center gap-2 font-semibold">
              <FlaskConical className="size-4 text-accent-foreground" aria-hidden="true" /> Experiments
            </h3>
            <ul className="mt-3 flex flex-wrap gap-2">
              {tools.map((t) => (
                <li key={t.id}>
                  <ResourceLink href={t.url}>{t.title}</ResourceLink>
                </li>
              ))}
            </ul>
            <p className="mt-3 text-sm">
              <Link to="/experiments" className="font-medium text-primary underline-offset-4 hover:underline">
                See the step-by-step experiment guides
              </Link>
            </p>
          </div>
          <div className="rounded-3xl border border-border bg-card p-5">
            <h3 className="flex items-center gap-2 font-semibold">
              <Video className="size-4 text-accent-foreground" aria-hidden="true" /> Videos
            </h3>
            <ul className="mt-3 flex flex-wrap gap-2">
              {videos.map((v) => (
                <li key={v.id}>
                  <ResourceLink href={v.url}>{v.title}</ResourceLink>
                </li>
              ))}
              <li>
                <ResourceLink href={videoLibrary.url}>{videoLibrary.title}</ResourceLink>
              </li>
            </ul>
          </div>
        </div>
      </section>

      {/* Final project */}
      <section aria-labelledby="final-heading" className="space-y-4">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div>
            <h2 id="final-heading" className="text-lg font-semibold tracking-tight">
              Final project: AI Innovation Canvas
            </h2>
            <p className="text-sm text-muted-foreground">
              Use it on November 17 and bring it back for Demo Day on December 1.
            </p>
          </div>
          {canvasDoc && (
            <a
              href={downloadHref(canvasDoc.file)}
              download
              className="inline-flex items-center gap-1.5 rounded-full border border-border bg-card px-3 py-1.5 text-sm font-medium transition-colors hover:border-primary hover:text-primary focus-visible:outline-hidden focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 print:hidden"
            >
              <Download className="size-3.5" aria-hidden="true" /> Download the canvas + Demo Day sheet
            </a>
          )}
        </div>
        <p className="rounded-2xl bg-accent px-4 py-3 text-sm font-medium text-accent-foreground">
          Design rule: {canvasDesignRule}
        </p>
        <ol className="grid gap-3 sm:grid-cols-3">
          {innovationCanvas.map((box, i) => (
            <li key={box.label} className="rounded-2xl border border-border bg-card p-4">
              <span className="text-xs font-semibold uppercase tracking-wide text-accent-foreground">
                {i + 1}. {box.label}
              </span>
              <p className="mt-1 text-sm">{box.prompt}</p>
            </li>
          ))}
        </ol>
        <div className="rounded-3xl border border-border bg-card p-5">
          <h3 className="font-semibold">Demo Day: {demoDay.heading}</h3>
          <p className="mt-1 text-sm">{demoDay.principle}</p>
          <p className="mt-3 text-xs font-semibold uppercase tracking-wide">Your 4-minute story</p>
          <ol className="mt-2 grid gap-2 sm:grid-cols-4">
            {demoDay.story.map((s) => (
              <li key={s.minute} className="rounded-2xl bg-muted/60 px-3 py-2 text-sm">
                <span className="font-semibold">Min {s.minute}:</span> {s.focus}
              </li>
            ))}
          </ol>
        </div>
      </section>
    </PageFrame>
  );
}
