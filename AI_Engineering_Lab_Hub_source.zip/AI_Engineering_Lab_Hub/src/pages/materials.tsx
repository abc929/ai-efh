import { Link } from "react-router-dom";
import { Download, FileText, Printer } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { PageFrame } from "@/components/page-frame";
import { downloads, getLab } from "@/data/course";
import { downloadHref } from "@/lib/download-href";

export function MaterialsPage() {
  return (
    <PageFrame
      eyebrow="Downloads"
      title="Downloadable materials"
      intro="The class handouts as Word documents, ready to print or share. Each one notes which sessions it is used on."
    >
      <ul className="grid gap-5 md:grid-cols-2" aria-label="Documents">
        {downloads.map((d) => {
          const usedLabs = d.usedOn.map(getLab).filter((l) => l !== undefined);
          const allSessions = usedLabs.length === 9;
          return (
            <li key={d.id} className="flex flex-col gap-4 rounded-3xl border border-border bg-card p-6">
              <div className="flex items-start gap-4">
                <span className="grid size-12 shrink-0 place-items-center rounded-2xl bg-accent text-accent-foreground" aria-hidden="true">
                  <FileText className="size-6" />
                </span>
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <Badge variant="secondary" className="rounded-full">
                      {d.audience}
                    </Badge>
                    <span className="text-xs text-muted-foreground">Word · about {d.sizeKb} KB</span>
                  </div>
                  <h2 className="mt-1 text-xl font-bold tracking-tight">{d.title}</h2>
                </div>
              </div>
              <p className="text-sm leading-relaxed">{d.description}</p>
              <div>
                <p className="text-xs font-semibold uppercase tracking-wide">Used on</p>
                {allSessions ? (
                  <p className="mt-1 text-sm">Every session, Sep 15 – Dec 1</p>
                ) : (
                  <ul className="mt-1.5 flex flex-wrap gap-1.5">
                    {usedLabs.map((l) => (
                      <li key={l.id}>
                        <Badge variant="outline" className="rounded-full">
                          {l.dateLabel} · {l.shortTitle}
                        </Badge>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
              <p className="break-all font-mono text-xs text-muted-foreground">{d.file}</p>
              <div className="mt-auto pt-1">
                <a
                  href={downloadHref(d.file)}
                  download
                  className="inline-flex items-center gap-2 rounded-full bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90 focus-visible:outline-hidden focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                >
                  <Download className="size-4" aria-hidden="true" /> Download
                </a>
              </div>
            </li>
          );
        })}
      </ul>

      <section aria-labelledby="print-heading" className="rounded-3xl border border-border bg-card p-6">
        <h2 id="print-heading" className="flex items-center gap-2 text-lg font-semibold tracking-tight">
          <Printer className="size-5 text-accent-foreground" aria-hidden="true" /> Print-friendly pages
        </h2>
        <p className="mt-1 text-sm text-muted-foreground">
          These pages drop the navigation when printed, so you can print straight from the browser.
        </p>
        <ul className="mt-4 grid gap-2 sm:grid-cols-3">
          <li>
            <Link
              to="/teacher-guides"
              className="block rounded-2xl border border-border bg-background px-4 py-3 text-sm font-medium transition-colors hover:border-primary hover:text-primary focus-visible:outline-hidden focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
            >
              Teacher guide for any session
            </Link>
          </li>
          <li>
            <Link
              to="/sub-plans"
              className="block rounded-2xl border border-border bg-background px-4 py-3 text-sm font-medium transition-colors hover:border-primary hover:text-primary focus-visible:outline-hidden focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
            >
              Substitute plans (both sub days)
            </Link>
          </li>
          <li>
            <Link
              to="/students"
              className="block rounded-2xl border border-border bg-background px-4 py-3 text-sm font-medium transition-colors hover:border-primary hover:text-primary focus-visible:outline-hidden focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
            >
              A student's filled-in AI Engineer Log
            </Link>
          </li>
        </ul>
      </section>
    </PageFrame>
  );
}
