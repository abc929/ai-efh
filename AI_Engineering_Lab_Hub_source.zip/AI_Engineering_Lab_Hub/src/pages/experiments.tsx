import { Link } from "react-router-dom";
import { Camera, FlaskConical, Play } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { PageFrame } from "@/components/page-frame";
import { ResourceLink } from "@/components/resource-link";
import { classInfo, getLab, getVideo, labsUsingTool, subPackets, tools } from "@/data/course";
import { useAppStore } from "@/lib/store";

export function ExperimentsPage() {
  const selectLab = useAppStore((s) => s.selectLab);
  const lab2 = getLab("lab-2");
  const lab6 = getLab("lab-6");

  return (
    <PageFrame
      eyebrow="Build and test"
      title="Experiments"
      intro="The hands-on tools the class trains and breaks, plus the step-by-step protocols from the student packets."
    >
      {/* Tools */}
      <section aria-labelledby="tools-heading" className="space-y-4">
        <h2 id="tools-heading" className="text-lg font-semibold tracking-tight">
          Experiment links
        </h2>
        <ul className="grid gap-5 md:grid-cols-2">
          {tools.map((t) => {
            const used = labsUsingTool(t.id);
            return (
              <li key={t.id} className="flex flex-col gap-4 rounded-3xl border border-border bg-card p-6">
                <div className="flex items-start gap-4">
                  <span className="grid size-12 shrink-0 place-items-center rounded-2xl bg-primary text-primary-foreground" aria-hidden="true">
                    <FlaskConical className="size-6" />
                  </span>
                  <div className="min-w-0">
                    <p className="text-xs font-semibold uppercase tracking-wide text-accent-foreground">{t.source}</p>
                    <h3 className="text-xl font-bold tracking-tight">{t.title}</h3>
                  </div>
                </div>
                {t.note && <p className="text-sm leading-relaxed">{t.note}</p>}
                <div>
                  <p className="text-xs font-semibold uppercase tracking-wide">Used in</p>
                  <ul className="mt-1.5 flex flex-wrap gap-1.5">
                    {used.map((l) => (
                      <li key={l.id}>
                        <Link
                          to="/teacher-guides"
                          onClick={() => selectLab(l.id)}
                          className="rounded-full focus-visible:outline-hidden focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                        >
                          <Badge variant="secondary" className="rounded-full">
                            Lab {l.number} · {l.dateLabel} · {l.openLabel?.includes("Pose") ? "Pose Project" : l.shortTitle}
                          </Badge>
                        </Link>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="mt-auto pt-1">
                  <ResourceLink href={t.url} variant="button">
                    Open {t.title}
                  </ResourceLink>
                </div>
              </li>
            );
          })}
        </ul>
        <div className="rounded-3xl border-l-4 border-marker bg-card p-5">
          <h3 className="flex items-center gap-2 font-semibold">
            <Camera className="size-4 text-marker" aria-hidden="true" /> Camera rule
          </h3>
          <p className="mt-2 text-sm leading-relaxed">{classInfo.cameraRule}</p>
        </div>
      </section>

      {/* Protocols */}
      <section aria-labelledby="protocols-heading" className="space-y-4">
        <div>
          <h2 id="protocols-heading" className="text-lg font-semibold tracking-tight">
            Step-by-step protocols
          </h2>
          <p className="text-sm text-muted-foreground">
            Your job on every experiment: {classInfo.subDayJob}
          </p>
        </div>
        <div className="grid gap-5 lg:grid-cols-2">
          {subPackets.map((p) => {
            const lab = getLab(p.labId);
            const video = getVideo(p.watchFirst);
            const tool = tools.find((t) => t.id === p.open);
            return (
              <article key={p.labId} aria-labelledby={`protocol-${p.labId}`} className="rounded-3xl border border-border bg-card p-6">
                <div className="flex flex-wrap items-center gap-2">
                  {lab && <Badge className="rounded-full">Lab {lab.number}</Badge>}
                  <span className="text-sm font-medium">{p.dateLabel}</span>
                  <Badge variant="outline" className="rounded-full border-info text-foreground">
                    Sub day
                  </Badge>
                </div>
                <h3 id={`protocol-${p.labId}`} className="mt-2 text-xl font-bold tracking-tight">
                  {p.heading}
                </h3>
                {lab && <p className="mt-1 text-sm leading-relaxed">{lab.mission}</p>}
                <div className="mt-3 flex flex-wrap gap-2">
                  {video && (
                    <ResourceLink href={video.url}>
                      <Play className="size-3.5" aria-hidden="true" /> Watch first: {video.title}
                    </ResourceLink>
                  )}
                  {tool && <ResourceLink href={tool.url}>Open: {tool.title}</ResourceLink>}
                </div>
                <ol className="mt-4 space-y-2">
                  {p.steps.map((step, i) => (
                    <li key={step} className="flex gap-3 text-sm leading-relaxed">
                      <span className="grid size-6 shrink-0 place-items-center rounded-full bg-primary text-xs font-bold text-primary-foreground">
                        {i + 1}
                      </span>
                      <span>{step}</span>
                    </li>
                  ))}
                </ol>
                {lab && (
                  <p className="mt-4 rounded-2xl border-l-4 border-primary bg-accent px-4 py-3 text-sm">
                    <span className="font-semibold text-accent-foreground">Exit check: </span>
                    {lab.exitCheck}
                  </p>
                )}
              </article>
            );
          })}
        </div>

        <div className="grid gap-5 lg:grid-cols-2">
          {[lab2, lab6].map(
            (lab) =>
              lab && (
                <article key={lab.id} className="rounded-3xl border border-border bg-card p-6">
                  <div className="flex flex-wrap items-center gap-2">
                    <Badge className="rounded-full">Lab {lab.number}</Badge>
                    <span className="text-sm font-medium">{lab.dateLabel}</span>
                  </div>
                  <h3 className="mt-2 text-xl font-bold tracking-tight">{lab.title}</h3>
                  <p className="mt-1 text-sm leading-relaxed">{lab.mission}</p>
                  <p className="mt-3 rounded-2xl border-l-4 border-primary bg-accent px-4 py-3 text-sm">
                    <span className="font-semibold text-accent-foreground">Exit check: </span>
                    {lab.exitCheck}
                  </p>
                  <p className="mt-3 text-sm">
                    <Link
                      to="/teacher-guides"
                      onClick={() => selectLab(lab.id)}
                      className="font-medium text-primary underline-offset-4 hover:underline"
                    >
                      Open the teacher guide for this lab
                    </Link>
                  </p>
                </article>
              ),
          )}
        </div>
      </section>
    </PageFrame>
  );
}
